﻿using Microsoft.Kinect;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows;
using System.IO;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;



namespace KinectStreams
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        #region Members

        Mode _mode = Mode.Color;

        KinectSensor _sensor;
        MultiSourceFrameReader _reader;
        IList<Body> _bodies;
        bool _displayBody = false;
        bool RecordingStatus;
        int imageSerial;
        #endregion

        #region Constructor

        public MainWindow()
        {
            InitializeComponent();
        }

        #endregion

        #region Event handlers

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            _sensor = KinectSensor.GetDefault();

            if (_sensor != null)
            {
                _sensor.Open();
                RecordingStatus = false;
                _reader = _sensor.OpenMultiSourceFrameReader(FrameSourceTypes.Color | FrameSourceTypes.Depth | FrameSourceTypes.Infrared | FrameSourceTypes.Body);
                _reader.MultiSourceFrameArrived += Reader_MultiSourceFrameArrived;

                // Deleting all previous image in ./img directory
                System.IO.DirectoryInfo directory = new DirectoryInfo("./img/");
                foreach (FileInfo file in directory.GetFiles())
                {
                    file.Delete();
                }
            }
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            if (_reader != null)
            {
                _reader.Dispose();
            }

            if (_sensor != null)
            {
                _sensor.Close();
            }
        }

        void Reader_MultiSourceFrameArrived(object sender, MultiSourceFrameArrivedEventArgs e)
        {
            var reference = e.FrameReference.AcquireFrame();

            // Color
            using (var frame = reference.ColorFrameReference.AcquireFrame())
            {
                if (frame != null)
                {
                    if (_mode == Mode.Color)
                    {

                        ImageSource src = frame.ToBitmap();
                        BitmapSource recode;
                        recode = src as BitmapSource;
                        camera.Source = src;
                        if (RecordingStatus)
                        {
                            // JpegBitmapEncoder to save BitmapSource to file
                            // imageSerial is the serial of the sequential image
                            JpegBitmapEncoder encoder = new JpegBitmapEncoder();
                            encoder.Frames.Add(BitmapFrame.Create(recode));
                            using (var fs = new FileStream("./img/" + (imageSerial++) + ".jpeg", FileMode.Create, FileAccess.Write))
                            {
                                encoder.Save(fs);
                            }
                        }
                    }
                }
            }
            // Depth
            using (var frame = reference.DepthFrameReference.AcquireFrame())
            {
                if (frame != null)
                {
                    if (_mode == Mode.Depth)
                    {

                        ImageSource src = frame.ToBitmap();
                        BitmapSource recode;
                        recode = src as BitmapSource;
                        camera.Source = src;
                        if (RecordingStatus)
                        {
                            // JpegBitmapEncoder to save BitmapSource to file
                            // imageSerial is the serial of the sequential image
                            JpegBitmapEncoder encoder = new JpegBitmapEncoder();
                            encoder.Frames.Add(BitmapFrame.Create(recode));
                            using (var fs = new FileStream("./img/" + (imageSerial++) + ".jpeg", FileMode.Create, FileAccess.Write))
                            {
                                encoder.Save(fs);
                            }
                        }

                    }
                }
            }

            // Infrared
            using (var frame = reference.InfraredFrameReference.AcquireFrame())
            {
                if (frame != null)
                {
                    if (_mode == Mode.Infrared)
                    {


                        ImageSource src = frame.ToBitmap();
                        BitmapSource recode;
                        recode = src as BitmapSource;
                        camera.Source = src;
                        if (RecordingStatus)
                        {
                            // JpegBitmapEncoder to save BitmapSource to file
                            // imageSerial is the serial of the sequential image
                            JpegBitmapEncoder encoder = new JpegBitmapEncoder();
                            encoder.Frames.Add(BitmapFrame.Create(recode));
                            using (var fs = new FileStream("./img/" + (imageSerial++) + ".jpeg", FileMode.Create, FileAccess.Write))
                            {
                                encoder.Save(fs);                              
                            }
                        }

                    }
                }
            }

            // Body
            using (var frame = reference.BodyFrameReference.AcquireFrame())
            {
                if (frame != null)
                {
                    canvas.Children.Clear();

                    _bodies = new Body[frame.BodyFrameSource.BodyCount];

                    frame.GetAndRefreshBodyData(_bodies);

                    foreach (var body in _bodies)
                    {
                        if (body != null)
                        {
                            if (body.IsTracked)
                            {
                                // Draw skeleton.
                                if (_displayBody)
                                {
                                    canvas.DrawSkeleton(body);
                                }
                            }
                        }
                    }
                }
            }


        }

        private void Color_Click(object sender, RoutedEventArgs e)
        {
            _mode = Mode.Color;
        }

        private void Depth_Click(object sender, RoutedEventArgs e)
        {
            _mode = Mode.Depth;
        }

        private void Infrared_Click(object sender, RoutedEventArgs e)
        {
            _mode = Mode.Infrared;
        }

        private void Body_Click(object sender, RoutedEventArgs e)
        {
            _displayBody = !_displayBody;
        }

        private void start_Click(object sender, RoutedEventArgs e)
        {
            imageSerial = 0;
            RecordingStatus = true;
        }
        private void stop_Click(object sender, RoutedEventArgs e)
        {
            RecordingStatus = false;
            string destination = @"C:\Users\kailshen\Documents\kinecttest";
            string fname = "kinect_video.mp4";
            Process.Start("ffmpeg.exe", "-framerate 10 -i ./img/%d.jpeg -c:v libx264 -r 30 -pix_fmt yuv420p" + destination +fname);
            azureSave();
        }

        private void azureSave()
        {
            string connString = ConfigurationManager.ConnectionStrings["AzureStorageAccount"].ConnectionString;
            string localFolder = ConfigurationManager.AppSettings["sourceFolder"];
            string destContainer = ConfigurationManager.AppSettings["destContainer"];


            //storage acc ref
            Console.WriteLine(@"Connecting to storage account");
            CloudStorageAccount sa = CloudStorageAccount.Parse(connString);
            CloudBlobClient bc = sa.CreateCloudBlobClient();

            //get ref to container, creating if neccessary
            Console.WriteLine(@"Getting container reference");
            CloudBlobContainer container = bc.GetContainerReference(destContainer);

            //create if no exist
            container.CreateIfNotExists();

            foreach (var file in Directory.GetFiles(localFolder, "*.*", SearchOption.AllDirectories)){
                var blob = container.GetBlockBlobReference(file);
                blob.UploadFromFile(localFolder);

                Console.WriteLine("Uploaded {0}", file);
            }

            Console.WriteLine("Complete");
        }


        #endregion
    }

    public enum Mode
    {
        Color,
        Depth,
        Infrared
    }
}
